/* front end javascript ka sara kaam idhr */

function openNav() {
    document.getElementById("mySidepanel").style.width = "200px";
}

function closeNav() {
    document.getElementById("mySidepanel").style.width = "0";
}

var healthFacts = [
    "Regular physical activity can improve your muscle strength and boost your endurance.",
    "Exercise delivers oxygen and nutrients to your tissues and helps your cardiovascular system work more efficiently.",
    "A healthy diet can protect the human body against certain types of diseases, in particular noncommunicable diseases such as obesity, diabetes, cardiovascular diseases, some types of cancer and skeletal conditions.",
    "Good mental health allows you to think clearly, develop socially and learn new skills.",
    "Adequate sleep is a key part of a healthy lifestyle, and can benefit your heart, weight, mind, and more." // Add more health facts as needed
];

function displayRandomFact() {
    var randomIndex = Math.floor(Math.random() * healthFacts.length);
    var randomFact = healthFacts[randomIndex];
    document.getElementById('factDisplay').innerHTML = randomFact;
}
// Call the function when the page loads
window.onload = displayRandomFact;

function togglePasswordVisibility() {
    const passwordField = document.getElementById('password');
    const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordField.setAttribute('type', type);
    const eyeIcon = document.getElementById('eye-icon');
    if (eyeIcon.classList.contains('fa-regular')) {
        eyeIcon.classList.remove('fa-regular');
        eyeIcon.classList.add('fa-solid');
    }

    else {
        eyeIcon.classList.add('fa-regular');
        eyeIcon.classList.remove('fa-solid');
    }
}
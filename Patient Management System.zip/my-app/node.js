var express = require('express');
var app = express();
var sql = require("mssql");
var cors = require('cors');
const nodemailer = require('nodemailer');

// Use cors middleware
app.use(cors());

// config for your database
var config = {
    server: 'localhost',
    authentication: {
        type: 'default',
        options: {
            userName: 'sa',
            password: '1234'
        }
    },
    options: {
        encrypt: true,
        trustServerCertificate: true, // Enable trust for self-signed certificate
        database: 'HospitalManagementSystem',
        requestTimeout: 30000 // 30 seconds

    }
};

app.get('/patient', function (req, res) {
    // Get the email and password from the query parameters
    var email = req.query.email;
    var password = req.query.password;

    // Call the getUserDetail function to fetch user details from the database
    getPatientDetails(email, password, function (err, userDetails) {
        if (err) {
            console.error('Error fetching user details:', err);
            return res.status(500).send('Internal Server Error');
        }

        // Check if user details were found
        if (!userDetails || userDetails.length === 0) {
            console.log('User not found');
            return res.status(404).send('User not found');
        }

        // Send the user details as JSON response
        res.json(userDetails);
    });
});

app.post('/api/sendMail', async (req, res) => {
    const { email, title, text } = req.body;

    try {
        let transporter = nodemailer.createTransport({
            service: 'Gmail', // Example: Gmail
            auth: {
                user: 'arhamraza947@gmail.com', // Your email address
                pass: 'hngwyqzhrpyoehph' // Your email password or app password if using Gmail
            }
        });

        let mailOptions = {
            from: 'arhamraza947@gmail.com',
            to: email,
            subject: title, // Set the subject using the provided title
            text: text // Set the email body text using the provided text
        };

        let info = await transporter.sendMail(mailOptions);
        console.log('Email sent: ', info.response);

        res.json({ success: true });
    } catch (error) {
        console.error('Error occurred: ', error);
        res.status(500).json({ success: false, error: 'Failed to send email' });
    }
});

function getPatientDetails(email, password, callback) {
    // connect to your database
    sql.connect(config, function (err) {
        if (err) {
            console.log('Error connecting to database:', err);
            return callback(err, null);
        }

        console.log('Connected to database successfully');

        // create Request object
        var request = new sql.Request();

        // Set up input parameters for the function
        request.input('Email', sql.VarChar(25), email);
        request.input('Password', sql.VarChar(25), password);

        // Execute the function
        request.query(`SELECT * FROM dbo.getPatientDetails('${email}','${password}')`, function (err, recordset) {
            if (err) {
                console.log('Error executing query:', err);
                return callback(err, null);
            }
            console.log('Fetched user details from database:', recordset);

            callback(null, recordset.recordset);
        });
    });
}

const bodyParser = require('body-parser');

app.use(bodyParser.json()); // Parse JSON-encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // Parse URL-encoded bodies

app.post('/register-patient', function (req, res) {
    // Get data from the request body
    var dob = req.body.dob;
    var gender = req.body.gender;
    var contact = req.body.contact;
    var address = req.body.address;
    var email = req.body.email;
    var password = req.body.password;
    var patientName = req.body.patientName;

    // Call the registerPatient function
    registerPatient(patientName, dob, gender, contact, address, email, password, function (err, result) {
        if (err) {
            console.error('Error registering patient:', err);
            return res.status(500).send('Internal Server Error');
        }

        // Send the result as JSON response
        res.json(result);
    });
});

// Define the function to register a patient
function registerPatient(patientName, dob, gender, contact, address, email, password, callback) {
    // connect to your database
    sql.connect(config, function (err) {
        if (err) {
            console.log('Error connecting to database:', err);
            return callback(err, null);
        }

        console.log('Connected to database successfully');

        // create Request object
        var request = new sql.Request();

        // Set up input parameters for the stored procedure
        request.input('PatientName', sql.VarChar(200), patientName);
        request.input('DOB', sql.Date, dob);
        request.input('Gender', sql.Char(1), gender);
        request.input('Contact', sql.VarChar(20), contact);
        request.input('Address', sql.VarChar(255), address);
        request.input('Email', sql.VarChar(100), email);
        request.input('Password', sql.VarChar(100), password);

        // Execute the stored procedure
        request.execute('RegisterPatient', function (err, recordset) {
            if (err) {
                console.log('Error executing stored procedure:', err);
                return callback(err, null);
            }
            console.log('Patient registered successfully');

            callback(null, recordset);
        });
    });
}

app.get('/patient/medicalHistory', function (req, res) {
    // Get the patient ID from the query parameters
    var patientId = req.query.patientId;

    // Check if patientId is provided
    if (!patientId) {
        return res.status(400).send('Patient ID is required');
    }

    // Call the getPatientMedicalHistory function to fetch medical history details from the database
    getPatientMedicalHistory(patientId, function (err, medicalHistory) {
        if (err) {
            console.error('Error fetching medical history:', err);
            return res.status(500).send('Internal Server Error');
        }

        // Check if medical history details were found
        if (!medicalHistory || medicalHistory.length === 0) {
            console.log('Medical history not found for the patient');
            return res.status(404).send('Medical history not found for the patient');
        }

        // Send the medical history details as JSON response
        res.json(medicalHistory);
    });
});

function getPatientMedicalHistory(patientId, callback) {
    // Connect to the database
    sql.connect(config, function (err) {
        if (err) {
            console.log('Error connecting to database:', err);
            return callback(err, null);
        }

        console.log('Connected to database successfully');

        // Create Request object
        var request = new sql.Request();

        // Set up input parameter for the function
        request.input('Patientid', sql.Int, patientId);

        // Execute the function
        request.query(`SELECT * FROM dbo.PatientMedicalHistory(${patientId})`, function (err, recordset) {
            if (err) {
                console.log('Error executing query:', err);
                return callback(err, null);
            }
            console.log('Fetched medical history from database:', recordset);

            callback(null, recordset.recordset);
        });
    });
}

app.get('/patient/ongoingPrescriptions', function (req, res) {
    // Get the patient ID from the query parameters
    var patientId = req.query.patientId;

    // Check if patientId is provided
    if (!patientId) {
        return res.status(400).send('Patient ID is required');
    }

    // Call the getOngoingPrescriptions function to fetch ongoing prescriptions from the database
    getOngoingPrescriptions(patientId, function (err, prescriptions) {
        if (err) {
            console.error('Error fetching ongoing prescriptions:', err);
            return res.status(500).send('Internal Server Error');
        }

        // Check if prescriptions were found
        if (!prescriptions || prescriptions.length === 0) {
            console.log('No ongoing prescriptions found for the patient');
            return res.status(404).send('No ongoing treatment plans found for the patient');
        }

        // Send the prescriptions as JSON response
        res.json(prescriptions);
    });
});

function getOngoingPrescriptions(patientId, callback) {
    // Connect to the database
    sql.connect(config, function (err) {
        if (err) {
            console.log('Error connecting to database:', err);
            return callback(err, null);
        }

        console.log('Connected to database successfully');

        // Create Request object
        var request = new sql.Request();

        // Set up input parameter for the function
        request.input('PatientID', sql.Int, patientId);

        // Execute the function
        request.query(`SELECT * FROM dbo.GetOngoingPrescriptions(@PatientID)`, function (err, recordset) {
            if (err) {
                console.log('Error executing query:', err);
                return callback(err, null);
            }
            console.log('Fetched ongoing prescriptions from database:', recordset);

            callback(null, recordset.recordset);
        });
    });
}

app.get('/patient/ongoingMedications', function (req, res) {
    // Get the PatientID from the query parameters
    const patientId = req.query.patientId;

    // Call the function to fetch ongoing medications
    getAllOngoingMedications(patientId, function (err, medications) {
        if (err) {
            console.error('Error fetching ongoing medications:', err);
            return res.status(500).send('Internal Server Error');
        }

        // Check if any medications were found
        if (!medications || medications.length === 0) {
            console.log('No ongoing medications found');
            return res.status(404).send('No ongoing medications found');
        }

        // Send the medications as a JSON response
        res.json(medications);
    });
});

// Function to fetch ongoing medications from the database
function getAllOngoingMedications(patientId, callback) {
    // Connect to the database
    sql.connect(config, function (err) {
        if (err) {
            console.log('Error connecting to the database:', err);
            return callback(err, null);
        }

        console.log('Connected to the database successfully');

        // Create a request object
        const request = new sql.Request();

        // Set up the input parameter for the function
        request.input('PatientID', sql.Int, patientId);

        // Execute the function
        request.query(`SELECT * FROM dbo.GetAllOngoingMedications(@PatientID)`, function (err, recordset) {
            if (err) {
                console.log('Error executing query:', err);
                return callback(err, null);
            }
            console.log('Fetched ongoing medications from the database:', recordset);

            callback(null, recordset.recordset);
        });
    });
}
app.get('/patient/labProfile', function (req, res) {
    // Get the PatientID from the query parameters
    const patientId = req.query.patientId;

    // Call the function to fetch the patient lab profile
    getPatientLabProfile(patientId, function (err, labProfile) {
        if (err) {
            console.error('Error fetching patient lab profile:', err);
            return res.status(500).send('Internal Server Error');
        }

        // Check if any lab profile data was found
        if (!labProfile || labProfile.length === 0) {
            console.log('No lab profile found for the patient');
            return res.status(404).send('No lab profile found for the patient');
        }

        // Send the lab profile data as a JSON response
        res.json(labProfile);
    });
});

// Function to fetch patient lab profile from the database
function getPatientLabProfile(patientId, callback) {
    // Connect to the database
    sql.connect(config, function (err) {
        if (err) {
            console.log('Error connecting to the database:', err);
            return callback(err, null);
        }

        console.log('Connected to the database successfully');

        // Create a request object
        const request = new sql.Request();

        // Set up the input parameter for the function
        request.input('PatientID', sql.Int, patientId);

        // Execute the function
        request.query(`SELECT * FROM dbo.GetPatientLabProfile(@PatientID)`, function (err, recordset) {
            if (err) {
                console.log('Error executing query:', err);
                return callback(err, null);
            }
            console.log('Fetched patient lab profile from the database:', recordset);

            callback(null, recordset.recordset);
        });
    });
}

app.get('/patient/specificLabTest', function (req, res) {
    // Get the TestID and PatientID from the query parameters
    const testId = req.query.testId;
    const patientId = req.query.patientId;

    // Call the function to fetch the specific lab test details
    getSpecificLabTest(testId, patientId, function (err, labTestDetails) {
        if (err) {
            console.error('Error fetching specific lab test details:', err);
            return res.status(500).send('Internal Server Error');
        }

        // Check if any lab test details were found
        if (!labTestDetails || labTestDetails.length === 0) {
            console.log('No lab test details found for the given test ID and patient ID');
            return res.status(404).send('No lab test details found for the given test ID and patient ID');
        }

        // Send the lab test details data as a JSON response
        res.json(labTestDetails);
    });
});

// Function to fetch specific lab test details from the database
function getSpecificLabTest(testId, patientId, callback) {
    // Connect to the database
    sql.connect(config, function (err) {
        if (err) {
            console.log('Error connecting to the database:', err);
            return callback(err, null);
        }

        console.log('Connected to the database successfully');

        // Create a request object
        const request = new sql.Request();

        // Set up the input parameters for the function
        request.input('TestID', sql.Int, testId);
        request.input('PatientID', sql.Int, patientId);

        // Execute the function
        request.query(`SELECT * FROM dbo.GetSpecificLabTest(@TestID, @PatientID)`, function (err, recordset) {
            if (err) {
                console.log('Error executing query:', err);
                return callback(err, null);
            }
            console.log('Fetched specific lab test details from the database:', recordset);

            callback(null, recordset.recordset);
        });
    });
}

app.get('/appointment/invoice', async (req, res) => {
    const appointmentId = req.query.appointmentId;

    if (!appointmentId) {
        return res.status(400).send('AppointmentID is required');
    }

    try {
        const invoice = await getSpecificAppointmentInvoice(appointmentId);
        if (!invoice || invoice.length === 0) {
            return res.status(404).send('No invoice found for the appointment');
        }
        res.json(invoice);
    } catch (err) {
        console.error('Error fetching specific appointment invoice:', err);
        res.status(500).send('Internal Server Error');
    }
});

// Function to fetch specific appointment invoice from the database
async function getSpecificAppointmentInvoice(appointmentId) {
    try {
        // Connect to the database
        await sql.connect(config);

        // Create a request object
        const request = new sql.Request();

        // Set up the input parameter for the function
        request.input('AppointmentID', sql.Int, appointmentId);

        // Execute the function
        const result = await request.query(`
            SELECT * FROM dbo.getSpecificAppointmentInvoice(@AppointmentID)
        `);

        console.log('Fetched specific appointment invoice from the database:', result.recordset);
        return result.recordset;
    } catch (err) {
        console.error('Error executing query:', err);
        throw err;
    }
}

app.get('/prescription', async (req, res) => {
    const { patientId, specialization, doctorName } = req.query;

    if (!patientId || !specialization || !doctorName) {
        return res.status(400).send('PatientID, Specialization, and DoctorName are required');
    }

    try {
        const prescription = await getPrescription(patientId, specialization, doctorName);
        if (!prescription || prescription.length === 0) {
            return res.status(404).send('No prescription found for the patient');
        }
        res.json(prescription);
    } catch (err) {
        console.error('Error fetching prescription:', err);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/doctor/name', async (req, res) => {
    const patientId = req.query.patientId;
    const specialization = req.query.specialization;

    if (!patientId || !specialization) {
        return res.status(400).send('PatientID and specialization are required');
    }

    try {
        const doctorName = await getDoctorName(patientId, specialization);
        if (!doctorName || doctorName.length === 0) {
            return res.status(404).send('No doctor found for the patient and specialization');
        }
        res.json(doctorName);
    } catch (err) {
        console.error('Error fetching doctor name:', err);
        res.status(500).send('Internal Server Error');
    }
});

// Function to fetch doctor name from the database based on patient ID and specialization
async function getDoctorName(patientId, specialization) {
    try {
        await sql.connect(config);
        const request = new sql.Request();

        request.input('PatientID', sql.Int, patientId);
        request.input('Specialization', sql.VarChar(25), specialization);

        const result = await request.query(`
            SELECT * dbo.getDoctorName(@PatientID, @Specialization)
        `);

        console.log('Fetched doctor name from the database:', result.recordset);
        return result.recordset;
    } catch (err) {
        console.error('Error executing query:', err);
        throw err;
    } finally {
        sql.close();
    }
}
app.get('/doctor/specialization', async (req, res) => {
    const patientId = req.query.patientId;

    if (!patientId) {
        return res.status(400).send('PatientID is required');
    }

    try {
        const doctorSpecialization = await getDoctorSpecialization(patientId);
        if (!doctorSpecialization || doctorSpecialization.length === 0) {
            return res.status(404).send('No doctor specialization found for the patient');
        }
        res.json(doctorSpecialization);
    } catch (err) {
        console.error('Error fetching doctor specialization:', err);
        res.status(500).send('Internal Server Error');
    }
});

// Function to fetch distinct doctor specialization from the database based on patient ID
async function getDoctorSpecialization(patientId) {
    try {
        await sql.connect(config);
        const request = new sql.Request();

        request.input('PatientID', sql.Int, patientId);

        const result = await request.query(`
            SELECT * from dbo.getDoctorSpecialization(@PatientID)
        `);

        console.log('Fetched doctor specialization from the database:', result.recordset);
        return result.recordset;
    } catch (err) {
        console.error('Error executing query:', err);
        throw err;
    } finally {
        sql.close();
    }
}


app.get('/patient/prescriptions', async (req, res) => {
    const { patientId, specialization } = req.query;

    if (!patientId || !specialization) {
        return res.status(400).send('PatientID and specialization are required');
    }

    try {
        const prescriptions = await getPrescriptionNo(patientId, specialization);
        if (!prescriptions || prescriptions.length === 0) {
            return res.status(404).send('No prescriptions found for the patient with the given specialization');
        }
        res.json(prescriptions);
    } catch (err) {
        console.error('Error fetching prescriptions:', err);
        res.status(500).send('Internal Server Error');
    }
});

// Function to fetch prescriptions from the database
async function getPrescriptionNo(patientId, specialization) {
    try {
        // Connect to the database
        await sql.connect(config);

        // Create a request object
        const request = new sql.Request();

        // Set up the input parameters for the function
        request.input('PatientID', sql.Int, patientId);
        request.input('specialization', sql.VarChar(25), specialization);

        // Execute the function
        const result = await request.query(`
            SELECT * FROM dbo.getPrescriptionNo(@PatientID, @specialization)
        `);

        console.log('Fetched prescriptions from the database:', result.recordset);
        return result.recordset;
    } catch (err) {
        console.error('Error executing query:', err);
        throw err;
    }
}


app.get('/patient/appointments', async (req, res) => {
    const patientId = req.query.patientId;

    if (!patientId) {
        return res.status(400).send('PatientID is required');
    }

    try {
        const appointments = await getPatientAppointments(patientId);
        if (!appointments || appointments.length === 0) {
            return res.status(404).send('No appointments found for the patient');
        }
        res.json(appointments);
    } catch (err) {
        console.error('Error fetching patient appointments:', err);
        res.status(500).send('Internal Server Error');
    }
});

// Function to fetch patient appointments from the database
async function getPatientAppointments(patientId) {
    try {
        // Connect to the database
        await sql.connect(config);

        // Create a request object
        const request = new sql.Request();

        // Set up the input parameter for the function
        request.input('PatientID', sql.Int, patientId);

        // Execute the function
        const result = await request.query(`SELECT * FROM dbo.getPatientAppointments(@PatientID)`);
        console.log('Fetched patient appointments from the database:', result.recordset);

        return result.recordset;
    } catch (err) {
        console.error('Error executing query:', err);
        throw err;
    }
}

var server = app.listen(3000, function () {
    console.log('Server is running..');
});
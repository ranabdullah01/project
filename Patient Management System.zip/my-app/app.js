let a = 0;

async function sendEmail(email, title, text) {

    const data = {
        email: email,
        title: title,
        text: text
    };

    try {
        const response = await fetch('http://localhost:3000/api/sendMail', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const responseData = await response.json();

        if (responseData.success) {
            alert('Email sent successfully!');
        } else {
            alert('Failed to send email. Please try again later.');
        }
    } catch (error) {
        console.error('Error sending email:', error);
        alert('Failed to send email. Please try again later.');
    }
}


async function fetchPatientDetails() {
    var email = document.getElementById("uname").value;
    var password = document.getElementById("password").value;
    console.log(email + password)
    var url = 'http://localhost:3000/patient?email=' + encodeURIComponent(email) + '&password=' + encodeURIComponent(password);
    console.log(url)
    
    // Check lockout status
    const lockoutInfo = JSON.parse(localStorage.getItem('lockoutInfo'));
    const currentTime = new Date().getTime();
    
    if (lockoutInfo && lockoutInfo.attempts >= 3) {
        const lockoutTime = 30 * 60 * 1000; // 30 minutes in milliseconds
        const timeSinceFirstAttempt = currentTime - lockoutInfo.firstAttemptTime;
        
        if (timeSinceFirstAttempt < lockoutTime) {
            const minutesLeft = Math.ceil((lockoutTime - timeSinceFirstAttempt) / (60 * 1000));
            alert(`Too many failed login attempts. Please try again in ${minutesLeft} minutes.`);
            return;
        } else {
            // Reset lockout info after 30 minutes
            localStorage.removeItem('lockoutInfo');
        }
    }
    
    try {
        const response = await fetch(url);
        if (!response.ok) {
            a++;
            
            // Store or update lockout info in localStorage
            if (!lockoutInfo) {
                localStorage.setItem('lockoutInfo', JSON.stringify({ attempts: 1, firstAttemptTime: currentTime }));
            } else {
                lockoutInfo.attempts += 1;
                localStorage.setItem('lockoutInfo', JSON.stringify(lockoutInfo));
            }
            
            return alert("Invalid Credentials!");
        }
        
        const patientDetails = await response.json();
        patient = patientDetails;
        console.log(patient)
        localStorage.setItem('patient', JSON.stringify(patient));
        window.location.pathname = "Home.html"
        
    } catch (error) {
        console.error('Error fetching patient details:', error);
    }
}

const currentPageName = window.location.pathname.split("/").pop();

async function getPatientLabProfile(patientId) {
    try {
        const response = await fetch(`http://localhost:3000/patient/labProfile?patientId=${patientId}`);

        if (!response.ok) {
            return alert("Error! No lab profile found for the patient.");
        }

        const labProfile = await response.json();
        console.log(labProfile);
        return labProfile;
    } catch (error) {
        console.error('Error fetching patient lab profile:', error);
        throw error;
    }
}


async function registerPatient(patientName, dob, gender, contact, address, email, password) {
    try {
        const response = await fetch('http://localhost:3000/register-patient', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                patientName: patientName,
                contact: contact,
                email: email,
                address: address,
                dob: dob,
                gender: gender,
                password: password
            })
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const result = await response.text();
        const text= 'You have been registered successfully!'
        await sendEmail(patient[0].Email, 'Registration Successful',text)
        return result;
    } catch (error) {
        console.error('Error registering patient:', error);
        throw error; // Rethrow the error to be caught by the caller
    }
}

async function getPatientMedicalHistory(patientId) {
    // Send a GET request to the server with the patient ID as a query parameter
    try {
        const response = await fetch(`http://localhost:3000/patient/medicalHistory?patientId=${patientId}`);

        if (!response.ok) {
            // If the response is not successful, throw an error
            return alert("Error! Such record does not exist!");
        }

        // Parse the response body as JSON
        const patientMedicalHistory = await response.json();
        // console.log(patientMedicalHistory);
        // Return the medical history details
        return patientMedicalHistory;
    } catch (error) {
        // Log any errors to the console
        console.error('Error fetching medical history:', error);
        // Throw the error to be handled by the caller
        throw error;
    }
}

async function getOngoingMedications(patientId) {
    try {
        const response = await fetch(`http://localhost:3000/patient/ongoingMedications?patientId=${patientId}`);

        if (!response.ok) {
            return console.log("Error! No ongoing medications found for the patient.");
        }

        const medications = await response.json();
        console.log(medications);
        return medications;
    } catch (error) {
        console.error('Error fetching ongoing medications:', error);
        // throw error;
        return null;
    }
}


async function getOngoingPrescriptions(patientId) {
    // Send a GET request to the server with the patient ID as a query parameter
    try {
        const response = await fetch(`http://localhost:3000/patient/ongoingPrescriptions?patientId=${patientId}`);

        if (!response.ok) {
            // If the response is not successful, alert the user
            return alert("Error! No ongoing treatment plans found for the patient.");
        }

        // Parse the response body as JSON
        const prescriptions = await response.json();
        console.log(prescriptions);
        // Return the prescriptions details
        return prescriptions;
    } catch (error) {
        // Log any errors to the console
        console.error('Error fetching ongoing prescriptions:', error);
        // Throw the error to be handled by the caller
        throw error;
    }
}

// Function to display ongoing prescriptions in the table
async function displayOngoingPrescriptionsInTable() {
    let patient = JSON.parse(localStorage.getItem('patient'))
    const prescriptions = getOngoingPrescriptions(patient[0].PatientID)
    console.log(prescriptions)
    const table = document.getElementById('medicineTable');

    // Clear existing rows except the header
    table.innerHTML = `
        <tr>
            <th>Prescription No.</th>
            <th>Medicine</th>
            <th>Dosage</th>
            <th>Quantity</th>
            <th>Frequency</th>
            <th>Duration</th>
            <th>Instructions</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Status</th>
        </tr>
    `;

    // Check if prescriptions data is empty
    if (prescriptions.length === 0) {
        const row = table.insertRow();
        const cell = row.insertCell(0);
        cell.colSpan = 10;
        cell.innerText = 'No ongoing treatment plans found for the patient';
        return;
    }

    // Populate table with prescription data
    prescriptions.forEach(prescription => {
        const row = table.insertRow();

        const cellPrescriptionNo = row.insertCell(0);
        const cellMedicine = row.insertCell(1);
        const cellDosage = row.insertCell(2);
        const cellQuantity = row.insertCell(3);
        const cellFrequency = row.insertCell(4);
        const cellDuration = row.insertCell(5);
        const cellInstructions = row.insertCell(6);
        const cellStartDate = row.insertCell(7);
        const cellEndDate = row.insertCell(8);
        const cellStatus = row.insertCell(9);

        cellPrescriptionNo.innerText = prescription.PrescriptionID;
        cellMedicine.innerText = prescription.MedicineName;
        cellDosage.innerText = prescription.Dosage;
        cellQuantity.innerText = prescription.Quantity;
        cellFrequency.innerText = prescription.Frequency;
        cellDuration.innerText = prescription.MedicineDuration;
        cellInstructions.innerText = prescription.Instructions;
        cellStartDate.innerText = prescription.PrescriptionDate;
        cellEndDate.innerText = prescription.EndDate;
        cellStatus.innerText = prescription.Status;
    });
}
async function displayLabDetails() {
    let patient = JSON.parse(localStorage.getItem('patient'));
    console.log("Patient Data:", patient);


    const patLabDetails = JSON.parse(localStorage.getItem('labTestDetails'))
    console.log("Patient Lab Details:", patLabDetails);
    if (currentPageName.toLocaleLowerCase() === "Labs.html") {
        displayLabProfileInTable(patLabDetails);
    }
    if (currentPageName === "invoice.html") {
        if (patLabDetails.length === 0) {
            console.error("No lab details found for the patient");
            return;
        }
        document.getElementById('PName').innerHTML = patLabDetails[0].PatientName
        document.getElementById('DName').innerHTML = patLabDetails[0].DoctorName
        document.getElementById('PresID').innerHTML = patLabDetails[0].PrescriptionID;
        document.getElementById('totalCost').innerHTML = "RS" + patLabDetails[0].Cost;
        document.getElementById('testCost').innerHTML = "RS" + patLabDetails[0].Cost;
        document.getElementById('testName').innerHTML = patLabDetails[0].TestName;
        document.getElementById('Date').innerHTML = patLabDetails[0].TestResultSchedule.toString().substring(0, 10);

    }
    if (currentPageName === "report.html") {
        if (patLabDetails.length === 0) {
            console.error("No lab details found for the patient");
            return;
        }

        document.getElementById('DName').innerHTML = patLabDetails[0].DoctorName;
        document.getElementById('PresID').innerHTML = patLabDetails[0].PrescriptionID;
        document.getElementById('Date').innerHTML = patLabDetails[0].TestResultSchedule.toString().substring(0, 10);
        document.getElementById('TestName').innerHTML = patLabDetails[0].TestName;
        document.getElementById('SampleID').innerHTML = patLabDetails[0].SampleID;

        const tableBody = document.getElementById('labDetailsTableBody');
        console.log("Table Body Element:", tableBody);

        // Clear any existing rows
        tableBody.innerHTML = '';

        // Populate table with lab details data
        patLabDetails.forEach(detail => {
            console.log("Processing Detail:", detail);

            const row = document.createElement('div');
            row.classList.add('row');

            const fieldCell = document.createElement('div');
            fieldCell.classList.add('column');
            fieldCell.innerText = detail.FieldName; // Field name
            row.appendChild(fieldCell);

            const resultCell = document.createElement('div');
            resultCell.classList.add('column');
            resultCell.innerText = detail.FieldResult; // Result value
            row.appendChild(resultCell);

            const normalRangeCell = document.createElement('div');
            normalRangeCell.classList.add('column');
            normalRangeCell.innerText = detail.NormalRange; // Normal range
            row.appendChild(normalRangeCell);

            tableBody.appendChild(row);
        });
    }

}

function displayLabProfileInTable(labProfile) {
    const table = document.getElementById('myTable');

    // Clear existing rows except the header
    table.innerHTML = `
        <tr>
            <th onclick="sortTable(0)">Lab</th>
            <th onclick="sortTable(1)">Date</th>
            <th onclick="sortTable(2)">Status</th>
            <th onclick="sortTable(3)">Result</th>
            <th onclick="sortTable(4)">Invoice</th>
        </tr>
    `;

    // Check if lab profile data is empty
    if (labProfile.length === 0) {
        const row = table.insertRow();
        const cell = row.insertCell(0);
        cell.colSpan = 5;
        cell.innerText = 'No lab profile found for the patient';
        return;
    }

    // Populate table with lab profile data
    labProfile.forEach(profile => {
        const row = table.insertRow();

        row.insertCell(0).innerText = profile.TestName; // Assuming TestName corresponds to Lab
        row.insertCell(1).innerText = new Date(profile.TestResultSchedule).toLocaleDateString(); // Format the date
        row.insertCell(2).innerText = profile.Status ? profile.Status : 'N/A'; // Status field
        row.insertCell(3).innerHTML = `<button id="reportBtn" class="btn btn-success" testID="${profile.TestID}">View Report</button></a>`;
        row.insertCell(4).innerHTML = `<button id="invoiceBtn" class="btn btn-danger" testID="${profile.TestID}">View Invoice</button></a>`;

        const reportBtn = document.getElementById("reportBtn")
        const invoiceBtn = document.getElementById("invoiceBtn")
        reportBtn.addEventListener("click", async () => {
            const testID = reportBtn.getAttribute('TestID');
            let patient = JSON.parse(localStorage.getItem('patient'))

            const patientID = patient[0].PatientID;
            let labTestDetails = await getSpecificLabTest(testID, patientID)
            localStorage.setItem('labTestDetails', JSON.stringify(labTestDetails));
            window.location.pathname = "report.html"

        })
        invoiceBtn.addEventListener("click", async () => {
            const testID = invoiceBtn.getAttribute('TestID');
            let patient = JSON.parse(localStorage.getItem('patient'))

            const patientID = patient[0].PatientID;
            let labTestDetails = await getSpecificLabTest(testID, patientID)
            localStorage.setItem('labTestDetails', JSON.stringify(labTestDetails));
            window.location.pathname = "invoice.html"

        })

    });
}



async function displayPatientAppointments() {
    let patient = JSON.parse(localStorage.getItem('patient'));
    console.log("Patient Data:", patient);

    if (!patient || patient.length === 0) {
        console.error("No patient data found in localStorage");
        return;
    }

    try {
        const response = await fetch(`http://localhost:3000/patient/appointments?patientId=${patient[0].PatientID}`);
        if (!response.ok) {
            throw new Error(`Error fetching patient appointments: ${response.statusText}`);
        }
        const appointments = await response.json();
        console.log("Patient Appointments:", appointments);
        if (currentPageName === "Home.html") {
            document.getElementById('appNum').innerHTML = appointments.length;
        }
        const scheduledAppointmentsBody = document.getElementById('scheduledAppointmentsBody');
        const previousAppointmentsBody = document.getElementById('previousAppointmentsBody');

        // Clear any existing rows
        scheduledAppointmentsBody.innerHTML = '';
        previousAppointmentsBody.innerHTML = '';

        // Populate tables with appointment data
        appointments.forEach(appointment => {
            const row = document.createElement('tr');

            const doctorCell = document.createElement('td');
            doctorCell.innerText = appointment.DoctorName;
            row.appendChild(doctorCell);

            const specializationCell = document.createElement('td');
            specializationCell.innerText = appointment.Specialization || 'N/A';  // Handle missing specialization
            row.appendChild(specializationCell);

            const dateCell = document.createElement('td');
            dateCell.innerText = appointment.Date;
            row.appendChild(dateCell);

            const timeCell = document.createElement('td');
            timeCell.innerText = appointment.Time;
            row.appendChild(timeCell);

            const invoiceCell = document.createElement('td');
            const invoiceButton = document.createElement('button');
            invoiceButton.classList.add('btn', 'btn-danger');
            invoiceButton.textContent = 'View Invoice';
            invoiceButton.setAttribute('id', 'aInvoiceBtn');
            invoiceButton.setAttribute('app-id', appointment.AppointmentID);

            invoiceButton.addEventListener('click', async () => {
                const appID = invoiceButton.getAttribute('app-id');
                try {
                    const invoiceData = await fetchAppointmentInvoice(appID);
                    localStorage.setItem('invoiceData', JSON.stringify(invoiceData));
                    window.location.pathname = "appointment-invoice.html";
                } catch (error) {
                    console.error('Error fetching appointment invoice:', error);
                }
            });

            invoiceCell.appendChild(invoiceButton);
            row.appendChild(invoiceCell);


            if (appointment.Status.toLowerCase() === 'pending') {
                scheduledAppointmentsBody.appendChild(row);
            } else {
                previousAppointmentsBody.appendChild(row);
            }
        });
    } catch (err) {
        console.error(err);
    }
}

async function fetchAppointmentInvoice(appointmentId) {
    try {
        const response = await fetch(`http://localhost:3000/appointment/invoice?appointmentId=${appointmentId}`);

        if (!response.ok) {
            throw new Error(`Error fetching appointment invoice: ${response.statusText}`);
        }

        const invoice = await response.json();
        console.log('Fetched appointment invoice:', invoice);
        return invoice;
    } catch (error) {
        console.error('Error fetching appointment invoice:', error);
        throw error;
    }
}

async function getSpecificLabTest(testId, patientId) {
    try {
        const response = await fetch(`http://localhost:3000/patient/specificLabTest?testId=${testId}&patientId=${patientId}`);
        if (!response.ok) {
            throw new Error(`Error fetching lab test details: ${response.statusText}`);
        }
        const labTestDetails = await response.json();
        return labTestDetails;
    } catch (error) {
        console.error(error);
        return null;
    }
}


if (currentPageName === "appointment-invoice.html") {
    let invoiceData = JSON.parse(localStorage.getItem('invoiceData'))
    console.log(invoiceData)
    document.getElementById("DoctorName").innerHTML = invoiceData[0].DoctorName
    document.getElementById("Specialty").innerHTML = invoiceData[0].Specialization
    document.getElementById('Date').innerHTML = invoiceData[0].Date.toString().substring(0, 10);
    document.getElementById('Time').innerHTML = invoiceData[0].Time.toString().substring(0, 10);
    document.getElementById('totalCost').innerHTML = "RS" + invoiceData[0].OPDCharges


}
if (currentPageName === "Appointments.html") {
    displayPatientAppointments();
}
if (currentPageName === "Home.html") {
    const name = document.getElementById('name')
    let patient = JSON.parse(localStorage.getItem('patient'))

    name.innerHTML += patient[0].PatientName + ','
    let appoinments = document.getElementsByClassName('appointments');
    appoinments[0].addEventListener('click', () => {
        window.location.pathname = "Appointments.html"
    })

    let test = document.getElementsByClassName('lab-tests');
    test[0].addEventListener('click', () => {
        window.location.pathname = "Labs.html"
    })
    let prescription = document.getElementsByClassName('prescriptions');
    prescription[0].addEventListener('click', () => {
        window.location.pathname = "TPlans.html"
    })
    displayMedications()
    displayLabs()
    displayAppointments()
}
if (currentPageName === "Prescription.html") {
    loadPrescriptionPage();
    document.getElementsByClassName('table-container')[0].style.display = "none";
}
async function loadPrescriptionPage() {
    let patient = JSON.parse(localStorage.getItem('patient'))

    await getDoctorSpecialization(patient[0].PatientID);
    let spec = document.getElementById("specialization").value;
    console.log(spec)
    await getPrescriptions(patient[0].PatientID, spec)
}
// Function to fetch doctor specialization based on patient ID from the server
async function getDoctorSpecialization(patientId) {
    try {
        const response = await fetch(`http://localhost:3000/doctor/specialization?patientId=${patientId}`);
        if (!response.ok) {
            throw new Error(`Error fetching doctor specialization: ${response.statusText}`);
        }
        const specializationData = await response.json();
        console.log("Doctor Specialization:", specializationData);

        // Get the specialization dropdown element
        const specializationDropdown = document.getElementById('specialization');

        // Clear existing options
        specializationDropdown.innerHTML = '';

        // Add default option
        const defaultOption = document.createElement('option');
        defaultOption.value = '';
        defaultOption.textContent = 'Select Specialization';
        defaultOption.disabled = true;
        defaultOption.selected = true;
        specializationDropdown.appendChild(defaultOption);

        // Add fetched specialization options
        specializationData.forEach(spec => {
            specializationDropdown.innerHTML = `<option value="${spec.Specialization}">${spec.Specialization}</option>`
        });

        return specializationData;
    } catch (err) {
        console.error(err);
        throw err;
    }
}
async function getPrescriptions(patientId, specialization) {
    try {
        const response = await fetch(`http://localhost:3000/patient/prescriptions?patientId=${patientId}&specialization=${specialization}`);
        if (!response.ok) {
            throw new Error(`Error fetching prescriptions: ${response.statusText}`);
        }
        const prescriptionData = await response.json();
        console.log("Prescriptions:", prescriptionData);

        // Update the PrescriptionNumber select element
        const prescriptionSelect = document.getElementById('PrescriptionNumber');
        prescriptionSelect.innerHTML = '<option value="" selected disabled>Prescription Number</option>'; // Clear existing options
        const seenPrescriptionIds = new Set(); // to keep track of seen prescription IDs
        prescriptionData.forEach(prescription => {
            // Check if the prescription ID is not seen before adding it to the select
            if (!seenPrescriptionIds.has(prescription.PrescriptionID)) {
                prescriptionSelect.innerHTML += `<option value="${prescription.PrescriptionID}" >${prescription.PrescriptionID}</option>`;
                seenPrescriptionIds.add(prescription.PrescriptionID); // add the ID to the set
            }
        });
        const tableBody = document.getElementById('medicinesTableBody');
        tableBody.innerHTML = ''; // Clear existing rows

        prescriptionData.forEach(prescription => {
            const row = document.createElement('tr');

            const medicineCell = document.createElement('td');
            medicineCell.textContent = prescription.MedicineName;
            row.appendChild(medicineCell);

            const dosageCell = document.createElement('td');
            dosageCell.textContent = prescription.Dosage;
            row.appendChild(dosageCell);

            const quantityCell = document.createElement('td');
            quantityCell.textContent = prescription.Quantity;
            row.appendChild(quantityCell);

            const frequencyCell = document.createElement('td');
            frequencyCell.textContent = prescription.Frequency;
            row.appendChild(frequencyCell);

            const durationCell = document.createElement('td');
            durationCell.textContent = prescription.MedicineDuration;
            row.appendChild(durationCell);

            const instructionsCell = document.createElement('td');
            instructionsCell.textContent = prescription.Instructions;
            row.appendChild(instructionsCell);

            tableBody.appendChild(row);
        });
        const submit = document.getElementById('sBtn')
        submit.addEventListener('click', () => {
            document.getElementsByClassName('table-container')[0].style.display = "block";

            document.getElementById("dName").innerHTML += prescriptionData[0].DoctorName
            document.getElementById("did").innerHTML += prescriptionData[0].DiagnosisName
            document.getElementById("pid").innerHTML += prescriptionData[0].AppointmentID
            document.getElementById("cnotes").innerHTML += prescriptionData[0].ClinicalNotes
            document.getElementById("lid").innerHTML += prescriptionData[0].Testname
        })

        return prescriptionData;
    } catch (err) {
        console.error(err);
        throw err;
    }
}



// Function to fetch prescription data based on patient ID, specialization, and doctor name from the server
async function getPrescription(patientId, specialization, doctorName) {
    try {
        const response = await fetch(`http://localhost:3000/prescription?patientId=${patientId}&specialization=${specialization}&doctorName=${doctorName}`);
        if (!response.ok) {
            throw new Error(`Error fetching prescription data: ${response.statusText}`);
        }
        const prescriptionData = await response.json();
        console.log("Prescription Data:", prescriptionData);
        return prescriptionData;
    } catch (err) {
        console.error(err);
        throw err;
    }
}


async function displayAppointments() {
    let patient = JSON.parse(localStorage.getItem('patient'))
    try {
        let appointments = await displayPatientAppointments(patient[0].PatientID)
        console.log(appointments)
        if (!appointments) {
            appointments = [];
            appointments.length = 0;
        }
        document.getElementById('appNum').innerHTML = appointments.length;
    }
    catch (error) {
        // Log any errors to the console
        console.error('Error fetching patient details:', error);
        // Throw the error to be handled by the caller
        throw error;
    }


}
async function displayLabs() {
    let patient = JSON.parse(localStorage.getItem('patient'))

    try {
        let patLabDetails = await getPatientLabProfile(patient[0].PatientID)

        if (!patLabDetails) {
            patLabDetails = [];
            patLabDetails.length = 0;
        }
        document.getElementById('tNum').innerHTML = patLabDetails.length;
    }
    catch (error) {
        // Log any errors to the console
        console.error('Error fetching patient details:', error);
        // Throw the error to be handled by the caller
        throw error;
    }
}

if (currentPageName === "labs.html" || currentPageName === "Labs.html") {
    displayLabReports();

}
async function displayLabReports() {
    let patient = JSON.parse(localStorage.getItem('patient'))
    const patLabDetails = await getPatientLabProfile(patient[0].PatientID)
    displayLabProfileInTable(patLabDetails)
}
if (currentPageName === "report.html") {
    displayLabDetails()
}
if (currentPageName === "invoice.html") {
    displayLabDetails()
}

async function displayMedications() {
    let patient = JSON.parse(localStorage.getItem('patient'))

    let medications = await getOngoingMedications(patient[0].PatientID)
    console.log(medications)

    if (!medications) {
        medications = [];
        medications.length = 0;
    }
    document.getElementById('mNum').innerHTML = medications.length;
}

if (currentPageName === 'Patients.html') {
    // fetchPatientDetails();
    let patient = JSON.parse(localStorage.getItem('patient'))

    displayMedicalHistory(patient[0].PatientID);
}

if (currentPageName === 'TPlans.html') {
    displayOngoingPrescriptionsInTable();
}

async function displayMedicalHistory(patientID) {
    try {
        let patient = JSON.parse(localStorage.getItem('patient'))

        const MedicalHistory = await getPatientMedicalHistory(patientID)
        console.log(MedicalHistory)
        document.getElementById("pID").innerText = patient[0].PatientID
        document.getElementById("pName").innerText = patient[0].PatientName
        document.getElementById("pAge").innerText = patient[0].Age
        document.getElementById("pContact").innerText = patient[0].Contact
        document.getElementById("pEmail").innerText = patient[0].Email
        document.getElementById("pAddress").innerText = patient[0].Address
        document.getElementById("DOB").innerText = patient[0].DOB.toString().substring(0, 10)
        document.getElementById("pStatus").innerText = patient[0].Status
        document.getElementById("pGender").innerText = patient[0].Gender
        document.getElementById("tHistory").innerText = MedicalHistory[0].TreatmentHistory;
        document.getElementById("allergies").innerText = MedicalHistory[0].Allergies;
        document.getElementById("prevSurgeries").innerText = MedicalHistory[0].PreviousSurgeries;
        document.getElementById("fHistory").innerText = MedicalHistory[0].FamilyHistory;
    }
    catch (error) {
        // Log any errors to the console
        console.error('Error fetching patient details:', error);
        // Throw the error to be handled by the caller
        throw error;
    }
}

if (currentPageName === "Registration.html") {
    let subBtn = document.getElementById("subBtn")
    subBtn.addEventListener('click', async () => {
        if (document.getElementById("pPassword").value === document.getElementById("pConfirmPassword").value) {
            const patientName = document.getElementById("pName").value
            const age = document.getElementById("pAge").value
            const contact = document.getElementById("pContact").value
            const email = document.getElementById("pEmail").value
            const address = document.getElementById("pAddress").value
            const dob = document.getElementById("pDate").value
            const password = document.getElementById("pPassword").value
            const gender = document.getElementById("pGender").value
            // console.log(patientName+contact+email+address+dob+gender+password)
            try {
                await registerPatient(patientName, dob, gender, contact, address, email, password);
                alert("Registration successful! Please login to continue.")
                window.location.pathname = "Home.html"
            }

            catch (error) {
                console.error('Error creating prescription:', error);
                throw error;
            }
        }
        else {
            alert("Passwords don't match!")
        }
    });
}


const submitBtn = document.getElementById("submitBtn");
submitBtn && submitBtn.addEventListener('click', async () => {
    fetchPatientDetails();
})